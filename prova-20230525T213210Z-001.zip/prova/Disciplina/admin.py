from django.contrib import admin
from .models import Disciplina
# Register your models here.

admin.site.register(Disciplina)