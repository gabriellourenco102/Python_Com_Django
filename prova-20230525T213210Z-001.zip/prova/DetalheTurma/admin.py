from django.contrib import admin
from .models import DetalheTurma

# Register your models here.

admin.site.register(DetalheTurma)